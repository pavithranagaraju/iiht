package com.nttdata.secureApp;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserREpository extends JpaRepository<User,Integer> {
	User findByUsername(String username);
	
	

}
