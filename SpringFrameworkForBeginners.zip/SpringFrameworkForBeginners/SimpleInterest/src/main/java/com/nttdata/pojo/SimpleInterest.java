package com.nttdata.pojo;

public class SimpleInterest {
private float principal,time,rate;

@Override
public String toString() {
	return "SimpleInterest [principal=" + principal + ", time=" + time + ", rate=" + rate + "]";
}

public float getPrincipal() {
	return principal;
}

public void setPrincipal(float principal) {
	this.principal = principal;
}

public float getTime() {
	return time;
}

public void setTime(float time) {
	this.time = time;
}

public float getRate() {
	return rate;
}

public void setRate(float rate) {
	this.rate = rate;
}
}
