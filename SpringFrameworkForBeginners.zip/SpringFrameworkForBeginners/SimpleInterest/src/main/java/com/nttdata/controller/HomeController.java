package com.nttdata.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nttdata.pojo.SimpleInterest;

@Controller
public class HomeController {

	@RequestMapping("/")
	public static ModelAndView SimpleInterestCalculatror(Model m){
		
		ModelAndView mv=new ModelAndView();
		mv.setViewName("view");
		m.addAttribute("SimpleInterest",new SimpleInterest());
		return mv;
		
	}
	
	@RequestMapping("/Result")
	public static ModelAndView Result(){
		
		ModelAndView mvr=new ModelAndView();
		mvr.setViewName("Result");
		
		return mvr;
		
	}
}
