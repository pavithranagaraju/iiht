package com.nttdata.pojo;

import java.util.List;
import java.util.Map;

public class Employee {
int id;
Map name;
long phno;
Address address;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}


public Map getName() {
	return name;
}
public void setName(Map name) {
	this.name = name;
}
public long getPhno() {
	return phno;
}
public void setPhno(long phno) {
	this.phno = phno;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
@Override
public String toString() {
	return "Employee [id=" + id + ", name=" + name + ", phno=" + phno + ", address=" + address + "]";
}

}
