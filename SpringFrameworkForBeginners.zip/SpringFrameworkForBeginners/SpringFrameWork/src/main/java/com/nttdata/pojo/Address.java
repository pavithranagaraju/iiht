package com.nttdata.pojo;

public class Address {
@Override
	public String toString() {
		return "Address [doorno=" + doorno + ", streetNo=" + streetNo + ", city=" + city + ", country=" + country
				+ ", pin=" + pin + "]";
	}
String doorno;
String streetNo;
String city;
String country;
int pin;
public String getDoorno() {
	return doorno;
}
public void setDoorno(String doorno) {
	this.doorno = doorno;
}
public String getStreetNo() {
	return streetNo;
}
public void setStreetNo(String streetNo) {
	this.streetNo = streetNo;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public int getPin() {
	return pin;
}
public void setPin(int pin) {
	this.pin = pin;
}
}
