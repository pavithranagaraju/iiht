package com.nttdata.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.catalina.ssi.SSICommand;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nttdata.pojo.Address;
import com.nttdata.pojo.Employee;

@RestController
public class HomeController {
	public static List<Employee> employee=new ArrayList<Employee>();
	
@RequestMapping(value="/init", method=RequestMethod.GET)
@ResponseBody
public void init(){
	Employee e=new Employee();
	Address a=new Address();
	a.setCity("Bangalore");
	a.setCountry("India");
	a.setDoorno("101");
	a.setPin(560059);
	a.setStreetNo("10");
	e.setId(1);
	e.setAddress(a);
	Map<String,String> name=new HashMap<String,String>();
	name.put("firstName", "Joe");
	name.put("middleName", "John");
	name.put("lastName", "Smith");
	e.setName(name);
	e.setPhno(8976564323l);
	
	
	employee.add(e);
	
	Employee e1=new Employee();
	Address a1=new Address();
	a1.setCity("Mysore");
	a1.setCountry("India");
	a1.setDoorno("121");
	a1.setPin(560099);
	a1.setStreetNo("11");
	e1.setId(2);
	e1.setAddress(a);
	Map<String,String> name1=new HashMap<String,String>();
	name1.put("firstName", "James");
	name1.put("middleName", "John");
	name1.put("lastName", "joe");
	e1.setName(name);
	e1.setPhno(9012345687l);
	
	employee.add(e1);
	
	
	
}
@RequestMapping(value="/getEmployee",method=RequestMethod.POST)
@ResponseBody
public String  getEmployee(){
	return employee.toString();
}

@RequestMapping(value="/getEmployeebyId",method=RequestMethod.POST)
@ResponseBody
public String  getEmployeebyId(@RequestParam Integer classID) throws JsonProcessingException{
	
if(employee.isEmpty()){
		
	}else{
	for (Employee e: employee) {
		if(e.getId()==classID)
		{
			ObjectMapper mapper = new ObjectMapper();
			String emp = mapper.writeValueAsString(e);
			return emp;
		}
	}
	}
	return "Employee with id "+classID+" Does not exist " ;
}

@RequestMapping(value = "/AddEmployee", method = RequestMethod.PUT)
@ResponseBody
public void AddEmployee(@RequestBody String addemp) throws JsonMappingException, JsonProcessingException {
	
	Employee em = new ObjectMapper().readValue(addemp, Employee.class);

employee.add(em);

}
@RequestMapping(value="/DeleteEmployee",method=RequestMethod.DELETE)
@ResponseBody
public void DeleteEmployee(@RequestParam("classID") Integer classID){
	if(employee.isEmpty()){
		
	}else{
	for (Employee e: employee) {
		
		if(e.getId()==classID){
			employee.remove(e);
		break;}
	}

	}
}


}
