package com.nttdata.Main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nttdata.pojo.Employee;

public class Driver {
public static void main(String[] args) {
	ApplicationContext applicationContext=new ClassPathXmlApplicationContext("Beans.xml");
	Employee e=(Employee)applicationContext.getBean("Employee");
	System.out.println(e);
}
}
